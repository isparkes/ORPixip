-- MySQL dump 10.13  Distrib 5.5.41-37.0, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: PixipDB
-- ------------------------------------------------------
-- Server version	5.5.41-37.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DESTINATION_MAP`
--

DROP TABLE IF EXISTS `DESTINATION_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DESTINATION_MAP` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `MAP_GROUP` varchar(24) DEFAULT NULL,
  `PREFIX` varchar(24) DEFAULT NULL,
  `ZONE_RESULT` varchar(64) DEFAULT NULL,
  `DESCRIPTION` varchar(64) DEFAULT NULL,
  `CATEGORY` varchar(24) DEFAULT NULL,
  `TYPE` varchar(24) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13775 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DESTINATION_MAP`
--

LOCK TABLES `DESTINATION_MAP` WRITE;
/*!40000 ALTER TABLE `DESTINATION_MAP` DISABLE KEYS */;
INSERT INTO `DESTINATION_MAP` VALUES (13481,'Default','00260','AA','Zone-260','International',NULL),(13482,'Default','0026096','AA','Zone-26096','International',NULL),(13483,'Default','00213','AA','Zone-213','International',NULL),(13484,'Default','00244','AA','Zone-244','International',NULL),(13485,'Default','00229','AA','Zone-229','International',NULL),(13486,'Default','00226','AA','Zone-226','International',NULL),(13487,'Default','00257','AA','Zone-257','International',NULL),(13488,'Default','00237','AA','Zone-237','International',NULL),(13489,'Default','00238','AA','Zone-238','International',NULL),(13490,'Default','00236','AA','Zone-236','International',NULL),(13491,'Default','00235','AA','Zone-235','International',NULL),(13492,'Default','00242','AA','Zone-242','International',NULL),(13493,'Default','00225','AA','Zone-225','International',NULL),(13494,'Default','00253','AA','Zone-253','International',NULL),(13495,'Default','0020','AA','Zone-20','International',NULL),(13496,'Default','00240','AA','Zone-240','International',NULL),(13497,'Default','00291','AA','Zone-291','International',NULL),(13498,'Default','00251','AA','Zone-251','International',NULL),(13499,'Default','00241','AA','Zone-241','International',NULL),(13500,'Default','00220','AA','Zone-220','International',NULL),(13501,'Default','00233','AA','Zone-233','International',NULL),(13502,'Default','00224','AA','Zone-224','International',NULL),(13503,'Default','00245','AA','Zone-245','International',NULL),(13504,'Default','00254','AA','Zone-254','International',NULL),(13505,'Default','00231','AA','Zone-231','International',NULL),(13506,'Default','00218','AA','Zone-218','International',NULL),(13507,'Default','00261','AA','Zone-261','International',NULL),(13508,'Default','00265','AA','Zone-265','International',NULL),(13509,'Default','00223','AA','Zone-223','International',NULL),(13510,'Default','00222','AA','Zone-222','International',NULL),(13511,'Default','00230','AA','Zone-230','International',NULL),(13512,'Default','00212','AA','Zone-212','International',NULL),(13513,'Default','0022997','AA','Zone-22997','International',NULL),(13514,'Default','002377','AA','Zone-2377','International',NULL),(13515,'Default','002426','AA','Zone-2426','International',NULL),(13516,'Default','0023324','AA','Zone-23324','International',NULL),(13517,'Default','0022464','AA','Zone-22464','International',NULL),(13518,'Default','002316','AA','Zone-2316','International',NULL),(13519,'Default','00234803','AA','Zone-234803','International',NULL),(13520,'Default','0024992','AA','Zone-24992','International',NULL),(13521,'Default','00227','AA','Zone-227','International',NULL),(13522,'Default','00234','AA','Zone-234','International',NULL),(13523,'Default','00675','AA','Zone-675','International',NULL),(13524,'Default','00262','AA','Zone-262','International',NULL),(13525,'Default','00250','AA','Zone-250','International',NULL),(13526,'Default','00239','AA','Zone-239','International',NULL),(13527,'Default','00221','AA','Zone-221','International',NULL),(13528,'Default','00232','AA','Zone-232','International',NULL),(13529,'Default','00252','AA','Zone-252','International',NULL),(13530,'Default','00290','AA','Zone-290','International',NULL),(13531,'Default','00255','AA','Zone-255','International',NULL),(13532,'Default','00256','AA','Zone-256','International',NULL),(13533,'Default','0025677','AA','Zone-25677','International',NULL),(13534,'Default','00228','AA','Zone-228','International',NULL),(13535,'Default','00216','AA','Zone-216','International',NULL),(13536,'Default','00243','AA','Zone-243','International',NULL),(13537,'Default','00248','AA','Zone-248','International',NULL),(13538,'Default','00249','AA','Zone-249','International',NULL),(13539,'Default','0022505','AA','Zone-22505','International',NULL),(13540,'Default','0022506','AA','Zone-22506','International',NULL),(13541,'Default','002375','AA','Zone-2375','International',NULL),(13542,'Default','0025008','AA','Zone-25008','International',NULL),(13543,'Default','0023746','AA','Zone-23746','International',NULL),(13544,'Default','0024567','AA','Zone-24567','International',NULL),(13545,'Default','00269','AA','Zone-269','International',NULL),(13546,'Default','0023745','AA','Zone-23745','International',NULL),(13547,'Default','007','AB','Zone-7','International',NULL),(13548,'Default','0060','AB','Zone-60','International',NULL),(13549,'Default','0061','AB','Zone-61','International',NULL),(13550,'Default','0062','AB','Zone-62','International',NULL),(13551,'Default','0063','AB','Zone-63','International',NULL),(13552,'Default','0064','AB','Zone-64','International',NULL),(13553,'Default','0065','AB','Zone-65','International',NULL),(13554,'Default','0066','AB','Zone-66','International',NULL),(13555,'Default','0081','AB','Zone-81','International',NULL),(13556,'Default','0082','AB','Zone-82','International',NULL),(13557,'Default','0084','AB','Zone-84','International',NULL),(13558,'Default','0086','AB','Zone-86','International',NULL),(13559,'Default','0087','AB','Zone-87','International',NULL),(13560,'Default','0090','AB','Zone-90','International',NULL),(13561,'Default','0091','AB','Zone-91','International',NULL),(13562,'Default','0092','AB','Zone-92','International',NULL),(13563,'Default','0093','AB','Zone-93','International',NULL),(13564,'Default','0094','AB','Zone-94','International',NULL),(13565,'Default','0095','AB','Zone-95','International',NULL),(13566,'Default','0098','AB','Zone-98','International',NULL),(13567,'Default','0046','AB','Zone-46','International',NULL),(13568,'Default','00670','AB','Zone-670','International',NULL),(13569,'Default','00671','AB','Zone-671','International',NULL),(13570,'Default','00673','AB','Zone-673','International',NULL),(13571,'Default','00674','AB','Zone-674','International',NULL),(13572,'Default','00676','AB','Zone-676','International',NULL),(13573,'Default','00677','AB','Zone-677','International',NULL),(13574,'Default','00678','AB','Zone-678','International',NULL),(13575,'Default','00679','AB','Zone-679','International',NULL),(13576,'Default','00680','AB','Zone-680','International',NULL),(13577,'Default','00681','AB','Zone-681','International',NULL),(13578,'Default','00682','AB','Zone-682','International',NULL),(13579,'Default','00683','AB','Zone-683','International',NULL),(13580,'Default','00686','AB','Zone-686','International',NULL),(13581,'Default','00687','AB','Zone-687','International',NULL),(13582,'Default','00688','AB','Zone-688','International',NULL),(13583,'Default','00690','AB','Zone-690','International',NULL),(13584,'Default','00691','AB','Zone-691','International',NULL),(13585,'Default','00692','AB','Zone-692','International',NULL),(13586,'Default','00808','AB','Zone-808','International',NULL),(13587,'Default','00850','AB','Zone-850','International',NULL),(13588,'Default','00852','AB','Zone-852','International',NULL),(13589,'Default','00853','AB','Zone-853','International',NULL),(13590,'Default','00855','AB','Zone-855','International',NULL),(13591,'Default','00856','AB','Zone-856','International',NULL),(13592,'Default','00880','AB','Zone-880','International',NULL),(13593,'Default','00905','AB','Zone-905','International',NULL),(13594,'Default','00960','AB','Zone-960','International',NULL),(13595,'Default','00961','AB','Zone-961','International',NULL),(13596,'Default','00963','AB','Zone-963','International',NULL),(13597,'Default','00964','AB','Zone-964','International',NULL),(13598,'Default','00966','AB','Zone-966','International',NULL),(13599,'Default','00967','AB','Zone-967','International',NULL),(13600,'Default','00968','AB','Zone-968','International',NULL),(13601,'Default','00970','AB','Zone-970','International',NULL),(13602,'Default','00971','AB','Zone-971','International',NULL),(13603,'Default','00972','AB','Zone-972','International',NULL),(13604,'Default','00973','AB','Zone-973','International',NULL),(13605,'Default','00974','AB','Zone-974','International',NULL),(13606,'Default','00975','AB','Zone-975','International',NULL),(13607,'Default','00976','AB','Zone-976','International',NULL),(13608,'Default','00977','AB','Zone-977','International',NULL),(13609,'Default','00992','AB','Zone-992','International',NULL),(13610,'Default','00993','AB','Zone-993','International',NULL),(13611,'Default','00996','AB','Zone-996','International',NULL),(13612,'Default','00998','AB','Zone-998','International',NULL),(13613,'Default','006723','AB','Zone-6723','International',NULL),(13614,'Default','007327','AB','Zone-7327','International',NULL),(13615,'Default','009891','AB','Zone-9891','International',NULL),(13616,'Default','0035796','AB','Zone-35796','International',NULL),(13617,'Default','0093722','AB','Zone-93722','International',NULL),(13618,'Default','0096394','AB','Zone-96394','International',NULL),(13619,'Default','0096395','AB','Zone-96395','International',NULL),(13620,'Default','0096773','AB','Zone-96773','International',NULL),(13621,'Default','0030','AC','Zone-30','International',NULL),(13622,'Default','0031','AC','Zone-31','International',NULL),(13623,'Default','0032','AC','Zone-32','International',NULL),(13624,'Default','0033','AC','Zone-33','International',NULL),(13625,'Default','0034','AC','Zone-34','International',NULL),(13626,'Default','0036','AC','Zone-36','International',NULL),(13627,'Default','0039','AC','Zone-39','International',NULL),(13628,'Default','0040','AC','Zone-40','International',NULL),(13629,'Default','0041','AC','Zone-41','International',NULL),(13630,'Default','0043','AC','Zone-43','International',NULL),(13631,'Default','0045','AC','Zone-45','International',NULL),(13632,'Default','0046','AC','Zone-46','International',NULL),(13633,'Default','0047','AC','Zone-47','International',NULL),(13634,'Default','0048','AC','Zone-48','International',NULL),(13635,'Default','0049','AC','Zone-49','International',NULL),(13636,'Default','00350','AC','Zone-350','International',NULL),(13637,'Default','00351','AC','Zone-351','International',NULL),(13638,'Default','00352','AC','Zone-352','International',NULL),(13639,'Default','00353','AC','Zone-353','International',NULL),(13640,'Default','00354','AC','Zone-354','International',NULL),(13641,'Default','00355','AC','Zone-355','International',NULL),(13642,'Default','00356','AC','Zone-356','International',NULL),(13643,'Default','00357','AC','Zone-357','International',NULL),(13644,'Default','00358','AC','Zone-358','International',NULL),(13645,'Default','00359','AC','Zone-359','International',NULL),(13646,'Default','00370','AC','Zone-370','International',NULL),(13647,'Default','00371','AC','Zone-371','International',NULL),(13648,'Default','00372','AC','Zone-372','International',NULL),(13649,'Default','00373','AC','Zone-373','International',NULL),(13650,'Default','00374','AC','Zone-374','International',NULL),(13651,'Default','00375','AC','Zone-375','International',NULL),(13652,'Default','00376','AC','Zone-376','International',NULL),(13653,'Default','00377','AC','Zone-377','International',NULL),(13654,'Default','00378','AC','Zone-378','International',NULL),(13655,'Default','00379','AC','Zone-379','International',NULL),(13656,'Default','00380','AC','Zone-380','International',NULL),(13657,'Default','00381','AC','Zone-381','International',NULL),(13658,'Default','00385','AC','Zone-385','International',NULL),(13659,'Default','00386','AC','Zone-386','International',NULL),(13660,'Default','00387','AC','Zone-387','International',NULL),(13661,'Default','00389','AC','Zone-389','International',NULL),(13662,'Default','00420','AC','Zone-420','International',NULL),(13663,'Default','00421','AC','Zone-421','International',NULL),(13664,'Default','00423','AC','Zone-423','International',NULL),(13665,'Default','00508','AC','Zone-508','International',NULL),(13666,'Default','00594','AC','Zone-594','International',NULL),(13667,'Default','00599','AC','Zone-599','International',NULL),(13668,'Default','00689','AC','Zone-689','International',NULL),(13669,'Default','00994','AC','Zone-994','International',NULL),(13670,'Default','00995','AC','Zone-995','International',NULL),(13671,'Default','001473','AC','Zone-1473','International',NULL),(13672,'Default','003393','AC','Zone-3393','International',NULL),(13673,'Default','0044','UK','Zone-44','International',NULL),(13674,'Default','001','AD','Zone-1','International',NULL),(13675,'Default','0051','AD','Zone-51','International',NULL),(13676,'Default','0052','AD','Zone-52','International',NULL),(13677,'Default','0053','AD','Zone-53','International',NULL),(13678,'Default','0054','AD','Zone-54','International',NULL),(13679,'Default','0055','AD','Zone-55','International',NULL),(13680,'Default','0056','AD','Zone-56','International',NULL),(13681,'Default','0057','AD','Zone-57','International',NULL),(13682,'Default','0058','AD','Zone-58','International',NULL),(13683,'Default','00247','AD','Zone-247','International',NULL),(13684,'Default','00297','AD','Zone-297','International',NULL),(13685,'Default','00298','AD','Zone-298','International',NULL),(13686,'Default','00299','AD','Zone-299','International',NULL),(13687,'Default','00500','AD','Zone-500','International',NULL),(13688,'Default','00501','AD','Zone-501','International',NULL),(13689,'Default','00502','AD','Zone-502','International',NULL),(13690,'Default','00503','AD','Zone-503','International',NULL),(13691,'Default','00504','AD','Zone-504','International',NULL),(13692,'Default','00505','AD','Zone-505','International',NULL),(13693,'Default','00506','AD','Zone-506','International',NULL),(13694,'Default','00507','AD','Zone-507','International',NULL),(13695,'Default','00509','AD','Zone-509','International',NULL),(13696,'Default','00590','AD','Zone-590','International',NULL),(13697,'Default','00591','AD','Zone-591','International',NULL),(13698,'Default','00592','AD','Zone-592','International',NULL),(13699,'Default','00593','AD','Zone-593','International',NULL),(13700,'Default','00595','AD','Zone-595','International',NULL),(13701,'Default','00596','AD','Zone-596','International',NULL),(13702,'Default','00597','AD','Zone-597','International',NULL),(13703,'Default','00598','AD','Zone-598','International',NULL),(13704,'Default','00684','AD','Zone-684','International',NULL),(13705,'Default','00685','AD','Zone-685','International',NULL),(13706,'Default','00869','AD','Zone-869','International',NULL),(13707,'Default','001242','AD','Zone-1242','International',NULL),(13708,'Default','001246','AD','Zone-1246','International',NULL),(13709,'Default','001264','AD','Zone-1264','International',NULL),(13710,'Default','001268','AD','Zone-1268','International',NULL),(13711,'Default','001281','AD','Zone-1281','International',NULL),(13712,'Default','001284','AD','Zone-1284','International',NULL),(13713,'Default','001340','AD','Zone-1340','International',NULL),(13714,'Default','001345','AD','Zone-1345','International',NULL),(13715,'Default','001441','AD','Zone-1441','International',NULL),(13716,'Default','001473','AD','Zone-1473','International',NULL),(13717,'Default','001649','AD','Zone-1649','International',NULL),(13718,'Default','001664','AD','Zone-1664','International',NULL),(13719,'Default','001670','AD','Zone-1670','International',NULL),(13720,'Default','001671','AD','Zone-1671','International',NULL),(13721,'Default','001758','AD','Zone-1758','International',NULL),(13722,'Default','001767','AD','Zone-1767','International',NULL),(13723,'Default','001784','AD','Zone-1784','International',NULL),(13724,'Default','001787','AD','Zone-1787','International',NULL),(13725,'Default','001808','AD','Zone-1808','International',NULL),(13726,'Default','001809','AD','Zone-1809','International',NULL),(13727,'Default','001829','AD','Zone-1829','International',NULL),(13728,'Default','001868','AD','Zone-1868','International',NULL),(13729,'Default','001869','AD','Zone-1869','International',NULL),(13730,'Default','001876','AD','Zone-1876','International',NULL),(13731,'Default','001907','AD','Zone-1907','International',NULL),(13732,'Default','00267','AE','Zone-267','International',NULL),(13733,'Default','0026771','AE','Zone-26771','International',NULL),(13734,'Default','00264','AE','Zone-264','International',NULL),(13735,'Default','00263','AE','Zone-263','International',NULL),(13736,'Default','00256','AF','Zone-256','International',NULL),(13737,'Default','0025677','AF','Zone-25677','International',NULL),(13738,'Default','00266','ZAC','Zone-266','International',NULL),(13739,'Default','005266','ZAC','Zone-5266','International',NULL),(13740,'Default','00258','ZAC','Zone-258','International',NULL),(13741,'Default','006258','ZAC','Zone-6258','International',NULL),(13742,'Default','002588','ZAC','Zone-2588','International',NULL),(13743,'Default','00277','ZAC','Zone-277','International',NULL),(13744,'Default','00278','ZAC','Zone-278','International',NULL),(13745,'Default','0027','ZA','Zone-27','International',NULL),(13746,'Default','00268','NAL','Zone-268','International',NULL),(13747,'Default','0026822','NAL','Zone-26822','International',NULL),(13748,'Default','0026823','NAL','Zone-26823','International',NULL),(13749,'Default','0026824','NAL','Zone-26824','International',NULL),(13750,'Default','0026825','NAL','Zone-26825','International',NULL),(13751,'Default','0026872','NAL','Zone-26872','International',NULL),(13752,'Default','0026873','NAL','Zone-26873','International',NULL),(13753,'Default','0026874','NAL','Zone-26874','International',NULL),(13754,'Default','0026875','NAL','Zone-26875','International',NULL),(13755,'Default','0026877','NAL','Zone-26877','International',NULL),(13756,'Default','00268504','NAL','Zone-268504','International',NULL),(13757,'Default','00268777','NAL','Zone-268777','International',NULL),(13758,'Default','002687504','NAL','Zone-2687504','International',NULL),(13759,'Default','0026877000000','NAL','Zone-26877000000','International',NULL),(13760,'Default','0090','NSCRZ','Zone-90','International',NULL),(13761,'Default','0094','NSCRZ','Zone-94','International',NULL),(13762,'Default','00100','NSCRZ','Zone-100','International',NULL),(13763,'Default','00112','NSCRZ','Zone-112','International',NULL),(13764,'Default','00910','NSCRZ','Zone-910','International',NULL),(13765,'Default','00911','NSCRZ','Zone-911','International',NULL),(13766,'Default','00922','NSCRZ','Zone-922','International',NULL),(13767,'Default','009220','NSCRZ','Zone-9220','International',NULL),(13768,'Default','00933','NSCRZ','Zone-933','International',NULL),(13769,'Default','00955','NSCRZ','Zone-955','International',NULL),(13770,'Default','00971','NSCRZ','Zone-971','International',NULL),(13771,'Default','00990','NSCRZ','Zone-990','International',NULL),(13772,'Default','00999','NSCRZ','Zone-999','International',NULL),(13773,'Default','00886','Taiwan','Zone-886','International',NULL),(13774,'Default','008008000','Free','Zone-8008000','Free',NULL);
/*!40000 ALTER TABLE `DESTINATION_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NORM_MAP`
--

DROP TABLE IF EXISTS `NORM_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NORM_MAP` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `MAP_GROUP` varchar(24) DEFAULT NULL,
  `BAND` varchar(24) DEFAULT NULL,
  `NUMBER` varchar(24) DEFAULT NULL,
  `OLD_PREFIX` varchar(24) DEFAULT NULL,
  `NEW_PREFIX` varchar(24) DEFAULT NULL,
  `RANK` varchar(24) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NORM_MAP`
--

LOCK TABLES `NORM_MAP` WRITE;
/*!40000 ALTER TABLE `NORM_MAP` DISABLE KEYS */;
INSERT INTO `NORM_MAP` VALUES (1,'VOICE','.*','268.*','','00','1'),(2,'VOICE','.*','\\+268.*','\\+','00','1'),(3,'GPRS','.*','.*','.*','00','1'),(4,'SMS','.*','268.*','','00','1'),(5,'SMS','.*','\\+268.*','\\+','00','1'),(6,'VOICE','.*','.*','','00','4'),(7,'SMS','.*','.*','','00','4'),(8,'VOICE','.*','........','','00268','2'),(9,'SMS','.*','........','','00268','2'),(10,'SMS','.*','\\+.*','\\+','00','3'),(11,'VOICE','.*','\\+.*','\\+','00','3');
/*!40000 ALTER TABLE `NORM_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRICE_MAP`
--

DROP TABLE IF EXISTS `PRICE_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRICE_MAP` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `MAP_GROUP` varchar(64) DEFAULT NULL,
  `SERVICE` varchar(64) DEFAULT NULL,
  `ORIGIN_ZONE` varchar(10) NOT NULL,
  `DEST_ZONE` varchar(10) NOT NULL,
  `ZONE_RESULT` varchar(64) NOT NULL,
  `TIME_RESULT` varchar(24) NOT NULL,
  `PRICE_GROUP` varchar(64) NOT NULL,
  `DESCRIPTION` varchar(64) NOT NULL,
  `RATE_PRICE` double DEFAULT NULL,
  `SETUP_PRICE` double DEFAULT NULL,
  `RATING_TYPE` varchar(24) DEFAULT NULL,
  `START_DATE` date NOT NULL DEFAULT '2000-01-01',
  `END_DATE` date NOT NULL DEFAULT '2030-01-01',
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRICE_MAP`
--

LOCK TABLES `PRICE_MAP` WRITE;
/*!40000 ALTER TABLE `PRICE_MAP` DISABLE KEYS */;
INSERT INTO `PRICE_MAP` VALUES (1,'PMB','VOICE','.*','.*','NAL','PEAK','PM_1_8','1.8 Per Sec',1.8,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(2,'PMB','VOICE','.*','.*','AE','PEAK','PM_5','5 Per Sec',5,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(3,'PMB','GPRS','.*','.*','GPRS','.*','PMD_1_14','1.14 Per Sec',1.14,0,'MBBeat1kB','2000-01-01','2030-01-01'),(4,'PMB','VOICE','.*','.*','NAL','OFFPEAK','PM_1_5','1.5 Per Sec',1.5,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(5,'PMB','VOICE','.*','.*','AE','OFFPEAK','PM_4_5','4.5 Per Sec',4.5,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(6,'Pay As You Go Dynamic PSB','VOICE','.*','.*','NAL','PEAK','PMS_0_04','0.04 Per Sec',0.04,0,'Beat1PS','2000-01-01','2030-01-01'),(8,'Pay As You Go Dynamic PSB','VOICE','.*','.*','NAL','OFFPEAK','PMS_0_04','0.04 Per Sec',0.04,0,'Beat1PS','2000-01-01','2030-01-01'),(9,'PS Zone(120)','VOICE','.*','.*','NAL','PEAK','PMS_0_04','0.04 Per Sec',0.04,0,'Beat1PS','2000-01-01','2030-01-01'),(10,'PS Zone(120)','VOICE','.*','.*','Taiwan','PEAK','PMS_6','6 Per Sec',6,0,'Beat1PS','2000-01-01','2030-01-01'),(11,'PS Zone(120)','VOICE','.*','.*','UK','PEAK','PMS_5_7','5.7 Per Sec',5.7,0,'Beat1PS','2000-01-01','2030-01-01'),(12,'PS Zone(120)','VOICE','.*','.*','Kuwait','PEAK','PMS_6','6 Per Sec',6,0,'Beat1PS','2000-01-01','2030-01-01'),(13,'PS Zone(120)','GPRS','.*','.*','GPRS','.*','PMD_1_14','1.14 Per Sec',1.14,0,'MBBeat1kB','2000-01-01','2030-01-01'),(14,'PS Zone(120)','VOICE','.*','.*','NAL','OFFPEAK','PMS_0_04','0.04 Per Sec',0.04,0,'Beat1PS','2000-01-01','2030-01-01'),(15,'PS Zone(120)','VOICE','.*','.*','Taiwan','OFFPEAK','PMS_5_8','5.8 Per Sec',5.8,0,'Beat1PS','2000-01-01','2030-01-01'),(16,'PS Zone(120)','VOICE','.*','.*','UK','OFFPEAK','PMS_5_5','5.5 Per Sec',5.5,0,'Beat1PS','2000-01-01','2030-01-01'),(17,'PS Zone(120)','VOICE','.*','.*','Kuwait','OFFPEAK','PMS_5_5','5.5 Per Sec',5.5,0,'Beat1PS','2000-01-01','2030-01-01'),(20,'Pay As You Go Dynamic PSB','SMS','.*','.*','NAL','.*','PME_0_8','0.08 Per Sec',0,0.8,'Event','2000-01-01','2030-01-01'),(22,'Pay As You Go Dynamic PSB','SMS','.*','.*','Taiwan','.*','PME_1_71','1.71 Per Sec',0,1.71,'Event','2000-01-01','2030-01-01'),(23,'Pay As You Go Dynamic PSB','SMS','.*','.*','ZAC','.*','PME_1_14','1.14 Per Sec',0,1.14,'Event','2000-01-01','2030-01-01'),(24,'Pay As You Go Dynamic PSB','SMS','.*','.*','UK','.*','PME_1_71','1.71 Per Sec',0,1.71,'Event','2000-01-01','2030-01-01'),(26,'PS Zone(120)','SMS','.*','.*','NAL','.*','PME_0_8','0.08 Per Sec',0,0.8,'Event','2000-01-01','2030-01-01'),(28,'PS Zone(120)','SMS','.*','.*','Taiwan','.*','PME_1_71','1.71 Per Sec',0,1.71,'Event','2000-01-01','2030-01-01'),(29,'PS Zone(120)','SMS','.*','.*','ZAC','.*','PME_1_14','1.14 Per Sec',0,1.14,'Event','2000-01-01','2030-01-01'),(30,'PS Zone(120)','SMS','.*','.*','UK','.*','PME_1_71','1.71 Per Sec',0,1.71,'Event','2000-01-01','2030-01-01'),(32,'PMB','SMS','.*','.*','NAL','.*','PME_0_8','0.08 Per Sec',0,0.8,'Event','2000-01-01','2030-01-01'),(34,'PMB','SMS','.*','.*','Taiwan','.*','PME_1_71','1.71 Per Sec',0,1.71,'Event','2000-01-01','2030-01-01'),(35,'PMB','SMS','.*','.*','ZAC','.*','PME_1_14','1.14 Per Sec',0,1.14,'Event','2000-01-01','2030-01-01'),(36,'PMB','SMS','.*','.*','UK','.*','PME_1_71','1.71 Per Sec',0,1.71,'Event','2000-01-01','2030-01-01'),(56,'PMB','SMS','.*','.*','AE','.*','PME_1_14','1.14 Per Sec',0,1.14,'Event','2000-01-01','2030-01-01'),(57,'Pay As You Go Dynamic PSB','SMS','.*','.*','AE','.*','PME_1_14','1.14 Per Sec',0,1.14,'Event','2000-01-01','2030-01-01'),(58,'PS Zone(120)','SMS','.*','.*','AE','.*','PME_1_14','1.14 Per Sec',0,1.14,'Event','2000-01-01','2030-01-01'),(68,'ANYTIME 750','VOICE','.*','.*','NAL','PEAK','PM-60-30_1_14','1.14 Per Sec',1.14,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(69,'ANYTIME 750','VOICE','.*','.*','AA','PEAK','PM-60-30_3_6','3.6 Per Sec',3.6,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(70,'ANYTIME 750','VOICE','.*','.*','AB','PEAK','PM-60-30_5_44','5.44 Per Sec',5.44,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(71,'ANYTIME 750','VOICE','.*','.*','ZAC','PEAK','PM-60-30_3_6','3.6 Per Sec',3.6,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(72,'ANYTIME 750','VOICE','.*','.*','NAL','OFFPEAK','PM-60-30_0_79','0.79 Per Sec',0.79,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(73,'ANYTIME 750','VOICE','.*','.*','AA','OFFPEAK','PM-60-30_3_42','3.42 Per Sec',3.42,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(74,'ANYTIME 750','VOICE','.*','.*','AB','OFFPEAK','PM-60-30_5_26','5.26 Per Sec',5.26,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(75,'ANYTIME 750','VOICE','.*','.*','AA','OFFPEAK','PM-60-30_3_42','3.42 Per Sec',3.42,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(76,'ANYTIME 750','VOICE','.*','.*','Free','.*','PM-60-30_0','0 Per Sec',0,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(77,'PMB','VOICE','.*','.*','NAL','VALUE','PM_0_9','0.9 Per Sec',0.9,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(79,'PS Zone(120)','VOICE','.*','.*','NAL','VALUE','PMS_0_04','0.04 Per Sec',0.04,0,'Beat1PS','2000-01-01','2030-01-01'),(80,'Pay As You Go Dynamic PSB','VOICE','.*','.*','NAL','VALUE','PMS_0_04','0.04 Per Sec',0.04,0,'Beat1PS','2000-01-01','2030-01-01'),(81,'ANYTIME 500','VOICE','.*','.*','NAL','PEAK','PM-60-30_1_27','1.27 Per Min',1.27,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(82,'ANYTIME 500','VOICE','.*','.*','AA','PEAK','PM-60-30_3_77','3.77 Per Min',3.77,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(83,'ANYTIME 500','VOICE','.*','.*','AB','PEAK','PM-60-30_5_53','5.53 Per Min',5.53,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(84,'ANYTIME 500','VOICE','.*','.*','ZAC','PEAK','PM-60-30_0','0 Per Min',0,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(85,'ANYTIME 500','VOICE','.*','.*','NAL','OFFPEAK','PM-60-30_0_79','0.79 Per Min',0.79,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(86,'ANYTIME 500','VOICE','.*','.*','AA','OFFPEAK','PM-60-30_3_51','3.51 Per Min',3.51,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(87,'ANYTIME 500','VOICE','.*','.*','AB','OFFPEAK','PM-60-30_5_53','5.53 Per Min',5.53,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(88,'ANYTIME 500','VOICE','.*','.*','AA','OFFPEAK','PM-60-30_0','0 Per Min',0,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(92,'DISTRIBUTOR PACKAGE','VOICE','.*','.*','NAL','PEAK','PMS_2_05','2.05 Per Sec',2.05,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(93,'DISTRIBUTOR PACKAGE','VOICE','.*','.*','NAL','OFFPEAK','PMS_1_6','1.6 Per Sec',1.6,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(94,'DISTRIBUTOR PACKAGE','VOICE','.*','.*','NAL','VALUE','PMS_1_03','1.03 Per Sec',1.03,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(95,'CONNECTA PLUS','VOICE','.*','.*','NAL','PEAK','PMS_1_45','1.45 Per Sec',1.45,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(96,'CONNECTA PLUS','VOICE','.*','.*','NAL','OFFPEAK','PMS_0_9','0.9 Per Sec',0.9,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(97,'CONNECTA PLUS','VOICE','.*','.*','NAL','VALUE','PMS_0_75','0.75 Per Sec',0.75,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(100,'ANYTIME 500','VOICE','.*','.*','NAL','VALUE','PM-60-30_0_66','0.66 Per Min',0.66,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(101,'ANYTIME 750','VOICE','.*','.*','NAL','VALUE','PM-60-30_0_66','0.66 Per Min',0.66,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(102,'Pay As You Go Dynamic PSB','VOICE','.*','.*','Taiwan','PEAK','PMS_6','6 Per Sec',6,0,'Beat1PS','2000-01-01','2030-01-01'),(103,'Pay As You Go Dynamic PSB','VOICE','.*','.*','Taiwan','OFFPEAK','PMS_5_8','5.8 Per Sec',5.8,0,'Beat1PS','2000-01-01','2030-01-01'),(104,'Pay As You Go Dynamic PSB','VOICE','.*','.*','Taiwan','VALUE','PMS_5_8','5.8 Per Sec',5.8,0,'Beat1PS','2000-01-01','2030-01-01'),(105,'Pay As You Go Dynamic PSB','VOICE','.*','.*','UK','PEAK','PMS_5_7','5.7 Per Sec',5.7,0,'Beat1PS','2000-01-01','2030-01-01'),(106,'Pay As You Go Dynamic PSB','VOICE','.*','.*','UK','OFFPEAK','PMS_5_5','5.5 Per Sec',5.5,0,'Beat1PS','2000-01-01','2030-01-01'),(107,'Pay As You Go Dynamic PSB','VOICE','.*','.*','UK','VALUE','PMS_5_5','5.5 Per Sec',5.5,0,'Beat1PS','2000-01-01','2030-01-01'),(108,'Pay As You Go Dynamic PSB','GPRS','.*','.*','GPRS','.*','PMD_1_14','1.14 Per Sec',1.14,0,'MBBeat1kB','2000-01-01','2030-01-01'),(109,'CONNECTA PLUS','GPRS','.*','.*','GPRS','.*','PMD_1_14','1.14 Per Sec',1.14,0,'MBBeat1kB','2000-01-01','2030-01-01'),(110,'PMB','VOICE','.*','.*','UK','PEAK','PM_5_1','5.1 Per Sec',5.1,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(111,'PMB','VOICE','.*','.*','UK','OFFPEAK','PM_4_9','4.9 Per Sec',4.9,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(112,'PMB','VOICE','.*','.*','AE','VALUE','PM_4_5','4.5 Per Sec',4.5,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(113,'PMB','VOICE','.*','.*','UK','VALUE','PM_4_9','4.9 Per Sec',4.9,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(114,'PMB','VOICE','.*','.*','ZA','PEAK','PM_3_5','3.5 Per Sec',3.5,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(115,'PMB','VOICE','.*','.*','ZA','OFFPEAK','PM_3_4','3.4 Per Sec',3.4,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(116,'PMB','VOICE','.*','.*','ZA','VALUE','PM_3_25','3.25 Per Sec',3.25,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(117,'PMB','VOICE','.*','.*','Taiwan','PEAK','PM_5_9','5.9 Per Sec',5.9,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(118,'PMB','VOICE','.*','.*','Taiwan','OFFPEAK','PM_5_6','5.6 Per Sec',5.6,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(119,'PMB','VOICE','.*','.*','Taiwan','VALUE','PM_5_6','5.6 Per Sec',5.6,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(120,'Pay As You Go Dynamic PSB','VOICE','.*','.*','ZA','PEAK','PM_4_7','4.7 Per Sec',4.7,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(121,'Pay As You Go Dynamic PSB','VOICE','.*','.*','ZA','OFFPEAK','PM_3_8','3.8 Per Sec',3.8,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(122,'Pay As You Go Dynamic PSB','VOICE','.*','.*','ZA','VALUE','PM_3_8','3.8 Per Sec',3.8,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(123,'Pay As You Go Dynamic PSB','VOICE','.*','.*','AE','PEAK','PM_5_1','5.1 Per Sec',5.1,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(124,'Pay As You Go Dynamic PSB','VOICE','.*','.*','AE','OFFPEAK','PM_4_65','4.65 Per Sec',4.65,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(125,'Pay As You Go Dynamic PSB','VOICE','.*','.*','AE','VALUE','PM_4_65','4.65 Per Sec',4.65,0,'Beat60,Beat30','2000-01-01','2030-01-01'),(144,'ANYTIME 500','GPRS','.*','.*','GPRS','.*','PMD_1','1 Per MB',1,0,'MBBeat1kB','2000-01-01','2030-01-01'),(145,'ANYTIME 750','GPRS','.*','.*','GPRS','.*','PMD_1','1 Per MB',1,0,'MBBeat1kB','2000-01-01','2030-01-01'),(146,'ANYTIME 500','SMS','.*','.*','NAL','.*','PME_0_7','0.7 Per Event',0,0.7,'Event','2000-01-01','2030-01-01'),(147,'ANYTIME 500','SMS','.*','.*','AE','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(148,'ANYTIME 500','SMS','.*','.*','Taiwan','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(149,'ANYTIME 500','SMS','.*','.*','ZAC','.*','PME_1','1 Per Event',0,1,'Event','2000-01-01','2030-01-01'),(150,'ANYTIME 500','SMS','.*','.*','UK','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(151,'ANYTIME 500','SMS','.*','.*','AE','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(152,'ANYTIME 500','SMS','.*','.*','AE','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(153,'ANYTIME 500','SMS','.*','.*','AB','.*','PME_0_7','0.7 Per Event',0,0.7,'Event','2000-01-01','2030-01-01'),(154,'ANYTIME 750','SMS','.*','.*','NAL','.*','PME_0_7','0.7 Per Event',0,0.7,'Event','2000-01-01','2030-01-01'),(155,'ANYTIME 750','SMS','.*','.*','AE','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(156,'ANYTIME 750','SMS','.*','.*','Taiwan','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(157,'ANYTIME 750','SMS','.*','.*','ZAC','.*','PME_1','1 Per Event',0,1,'Event','2000-01-01','2030-01-01'),(158,'ANYTIME 750','SMS','.*','.*','UK','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(159,'ANYTIME 750','SMS','.*','.*','AE','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(160,'ANYTIME 750','SMS','.*','.*','AE','.*','PME_1_3','1.3 Per Event',0,1.3,'Event','2000-01-01','2030-01-01'),(161,'ANYTIME 750','SMS','.*','.*','AB','.*','PME_0_7','0.7 Per Event',0,0.7,'Event','2000-01-01','2030-01-01'),(162,'DISTRIBUTOR PACKAGE','GPRS','.*','.*','GPRS','.*','PMD_1_14','1.14 Per Sec',1.14,0,'MBBeat1kB','2000-01-01','2030-01-01');
/*!40000 ALTER TABLE `PRICE_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRICE_MODEL`
--

DROP TABLE IF EXISTS `PRICE_MODEL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRICE_MODEL` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `PRICE_MODEL` varchar(64) NOT NULL,
  `STEP` int(11) NOT NULL DEFAULT '0',
  `TIER_FROM` int(11) DEFAULT NULL,
  `TIER_TO` int(11) DEFAULT NULL,
  `BEAT` double DEFAULT NULL,
  `FACTOR` double DEFAULT NULL,
  `CHARGE_BASE` double DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`),
  UNIQUE KEY `idx_price_model` (`PRICE_MODEL`,`STEP`)
) ENGINE=InnoDB AUTO_INCREMENT=2579 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRICE_MODEL`
--

LOCK TABLES `PRICE_MODEL` WRITE;
/*!40000 ALTER TABLE `PRICE_MODEL` DISABLE KEYS */;
INSERT INTO `PRICE_MODEL` VALUES (2437,'PME_0_8',1,0,0,1,0.8,1),(2438,'PME_1_71',1,0,0,1,1.71,1),(2439,'PME_1_14',1,0,0,1,1.14,1),(2440,'PME_0_7',1,0,0,1,0.7,1),(2441,'PME_1_3',1,0,0,1,1.3,1),(2442,'PME_1',1,0,0,1,1,1),(2444,'PMS_0_04',1,0,999999,1,0.04,1),(2445,'PMS_6',1,0,999999,1,6,1),(2446,'PMS_5_7',1,0,999999,1,5.7,1),(2447,'PMS_5_8',1,0,999999,1,5.8,1),(2448,'PMS_5_5',1,0,999999,1,5.5,1),(2451,'PM_1_8',1,0,60,60,1.8,60),(2452,'PM_5',1,0,60,60,5,60),(2453,'PM_1_5',1,0,60,60,1.5,60),(2454,'PM_4_5',1,0,60,60,4.5,60),(2455,'PM-60-30_1_14',1,0,60,60,1.14,60),(2456,'PM-60-30_3_6',1,0,60,60,3.6,60),(2457,'PM-60-30_5_44',1,0,60,60,5.44,60),(2458,'PM-60-30_0_79',1,0,60,60,0.79,60),(2459,'PM-60-30_3_42',1,0,60,60,3.42,60),(2460,'PM-60-30_5_26',1,0,60,60,5.26,60),(2461,'PM-60-30_0',1,0,60,60,0,60),(2462,'PM_0_9',1,0,60,60,0.9,60),(2463,'PM-60-30_1_27',1,0,60,60,1.27,60),(2464,'PM-60-30_3_77',1,0,60,60,3.77,60),(2465,'PM-60-30_5_53',1,0,60,60,5.53,60),(2466,'PM-60-30_3_51',1,0,60,60,3.51,60),(2467,'PMS_2_05',1,0,60,60,2.05,60),(2468,'PMS_1_6',1,0,60,60,1.6,60),(2469,'PMS_1_03',1,0,60,60,1.03,60),(2470,'PMS_1_45',1,0,60,60,1.45,60),(2471,'PMS_0_9',1,0,60,60,0.9,60),(2472,'PMS_0_75',1,0,60,60,0.75,60),(2473,'PM-60-30_0_66',1,0,60,60,0.66,60),(2474,'PM_5_1',1,0,60,60,5.1,60),(2475,'PM_4_9',1,0,60,60,4.9,60),(2476,'PM_3_5',1,0,60,60,3.5,60),(2477,'PM_3_4',1,0,60,60,3.4,60),(2478,'PM_3_25',1,0,60,60,3.25,60),(2479,'PM_5_9',1,0,60,60,5.9,60),(2480,'PM_5_6',1,0,60,60,5.6,60),(2481,'PM_4_7',1,0,60,60,4.7,60),(2482,'PM_3_8',1,0,60,60,3.8,60),(2483,'PM_4_65',1,0,60,60,4.65,60),(2514,'PM_1_8',2,60,999999,30,1.8,60),(2515,'PM_5',2,60,999999,30,5,60),(2516,'PM_1_5',2,60,999999,30,1.5,60),(2517,'PM_4_5',2,60,999999,30,4.5,60),(2518,'PM-60-30_1_14',2,60,999999,30,1.14,60),(2519,'PM-60-30_3_6',2,60,999999,30,3.6,60),(2520,'PM-60-30_5_44',2,60,999999,30,5.44,60),(2521,'PM-60-30_0_79',2,60,999999,30,0.79,60),(2522,'PM-60-30_3_42',2,60,999999,30,3.42,60),(2523,'PM-60-30_5_26',2,60,999999,30,5.26,60),(2524,'PM-60-30_0',2,60,999999,30,0,60),(2525,'PM_0_9',2,60,999999,30,0.9,60),(2526,'PM-60-30_1_27',2,60,999999,30,1.27,60),(2527,'PM-60-30_3_77',2,60,999999,30,3.77,60),(2528,'PM-60-30_5_53',2,60,999999,30,5.53,60),(2529,'PM-60-30_3_51',2,60,999999,30,3.51,60),(2530,'PMS_2_05',2,60,999999,30,2.05,60),(2531,'PMS_1_6',2,60,999999,30,1.6,60),(2532,'PMS_1_03',2,60,999999,30,1.03,60),(2533,'PMS_1_45',2,60,999999,30,1.45,60),(2534,'PMS_0_9',2,60,999999,30,0.9,60),(2535,'PMS_0_75',2,60,999999,30,0.75,60),(2536,'PM-60-30_0_66',2,60,999999,30,0.66,60),(2537,'PM_5_1',2,60,999999,30,5.1,60),(2538,'PM_4_9',2,60,999999,30,4.9,60),(2539,'PM_3_5',2,60,999999,30,3.5,60),(2540,'PM_3_4',2,60,999999,30,3.4,60),(2541,'PM_3_25',2,60,999999,30,3.25,60),(2542,'PM_5_9',2,60,999999,30,5.9,60),(2543,'PM_5_6',2,60,999999,30,5.6,60),(2544,'PM_4_7',2,60,999999,30,4.7,60),(2545,'PM_3_8',2,60,999999,30,3.8,60),(2546,'PM_4_65',2,60,999999,30,4.65,60),(2577,'PMD_1_14',1,0,999999999,1024,1.14,1024000),(2578,'PMD_1',1,0,999999999,1024,1,1024000);
/*!40000 ALTER TABLE `PRICE_MODEL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRICE_PLAN_HIERARCHY`
--

DROP TABLE IF EXISTS `PRICE_PLAN_HIERARCHY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PRICE_PLAN_HIERARCHY` (
  `ID` bigint(20) NOT NULL,
  `PRICE_PLAN` varchar(64) DEFAULT NULL,
  `PLAN_HIERARCHY` varchar(256) DEFAULT NULL,
  `PRIORITY` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRICE_PLAN_HIERARCHY`
--

LOCK TABLES `PRICE_PLAN_HIERARCHY` WRITE;
/*!40000 ALTER TABLE `PRICE_PLAN_HIERARCHY` DISABLE KEYS */;
INSERT INTO `PRICE_PLAN_HIERARCHY` VALUES (1,'voip_base','voip_base',0),(2,'voip_alltid','voip_alltid:voip_base',1),(3,'voip_corp_base','voip_corp_base',0),(4,'voip_corp_mobile','voip_corp_mobile:voip_corp_base',1),(5,'voip_base2','voip_base2',0),(6,'voip_international','voip_international:voip_base2',1),(7,'voip_mobile','voip_mobile:voip_base2',1),(8,'voip_mobile_international','voip_mobile_international:voip_base2',1),(9,'voip_alltid2','voip_alltid2:voip_base2',1);
/*!40000 ALTER TABLE `PRICE_PLAN_HIERARCHY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RATE_PRICE_PIVOT`
--

DROP TABLE IF EXISTS `RATE_PRICE_PIVOT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RATE_PRICE_PIVOT` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `PRICE_MODEL` varchar(64) DEFAULT NULL,
  `STEP` int(11) DEFAULT NULL,
  `TIER_FROM` int(11) DEFAULT NULL,
  `TIER_TO` int(11) DEFAULT NULL,
  `BEAT` double DEFAULT NULL,
  `FACTOR` double DEFAULT NULL,
  `CHARGE_BASE` double DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2580 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RATE_PRICE_PIVOT`
--

LOCK TABLES `RATE_PRICE_PIVOT` WRITE;
/*!40000 ALTER TABLE `RATE_PRICE_PIVOT` DISABLE KEYS */;
INSERT INTO `RATE_PRICE_PIVOT` VALUES (2437,'PME_0_8',1,0,0,1,0.8,1),(2438,'PME_1_71',1,0,0,1,1.71,1),(2439,'PME_1_14',1,0,0,1,1.14,1),(2440,'PME_0_7',1,0,0,1,0.7,1),(2441,'PME_1_3',1,0,0,1,1.3,1),(2442,'PME_1',1,0,0,1,1,1),(2444,'PMS_0_04',1,0,999999,1,0.04,1),(2445,'PMS_6',1,0,999999,1,6,1),(2446,'PMS_5_7',1,0,999999,1,5.7,1),(2447,'PMS_5_8',1,0,999999,1,5.8,1),(2448,'PMS_5_5',1,0,999999,1,5.5,1),(2451,'PM_1_8',1,0,60,60,1.8,60),(2452,'PM_5',1,0,60,60,5,60),(2453,'PM_1_5',1,0,60,60,1.5,60),(2454,'PM_4_5',1,0,60,60,4.5,60),(2455,'PM-60-30_1_14',1,0,60,60,1.14,60),(2456,'PM-60-30_3_6',1,0,60,60,3.6,60),(2457,'PM-60-30_5_44',1,0,60,60,5.44,60),(2458,'PM-60-30_0_79',1,0,60,60,0.79,60),(2459,'PM-60-30_3_42',1,0,60,60,3.42,60),(2460,'PM-60-30_5_26',1,0,60,60,5.26,60),(2461,'PM-60-30_0',1,0,60,60,0,60),(2462,'PM_0_9',1,0,60,60,0.9,60),(2463,'PM-60-30_1_27',1,0,60,60,1.27,60),(2464,'PM-60-30_3_77',1,0,60,60,3.77,60),(2465,'PM-60-30_5_53',1,0,60,60,5.53,60),(2466,'PM-60-30_3_51',1,0,60,60,3.51,60),(2467,'PMS_2_05',1,0,60,60,2.05,60),(2468,'PMS_1_6',1,0,60,60,1.6,60),(2469,'PMS_1_03',1,0,60,60,1.03,60),(2470,'PMS_1_45',1,0,60,60,1.45,60),(2471,'PMS_0_9',1,0,60,60,0.9,60),(2472,'PMS_0_75',1,0,60,60,0.75,60),(2473,'PM-60-30_0_66',1,0,60,60,0.66,60),(2474,'PM_5_1',1,0,60,60,5.1,60),(2475,'PM_4_9',1,0,60,60,4.9,60),(2476,'PM_3_5',1,0,60,60,3.5,60),(2477,'PM_3_4',1,0,60,60,3.4,60),(2478,'PM_3_25',1,0,60,60,3.25,60),(2479,'PM_5_9',1,0,60,60,5.9,60),(2480,'PM_5_6',1,0,60,60,5.6,60),(2481,'PM_4_7',1,0,60,60,4.7,60),(2482,'PM_3_8',1,0,60,60,3.8,60),(2483,'PM_4_65',1,0,60,60,4.65,60),(2514,'PM_1_8',2,60,999999,30,1.8,60),(2515,'PM_5',2,60,999999,30,5,60),(2516,'PM_1_5',2,60,999999,30,1.5,60),(2517,'PM_4_5',2,60,999999,30,4.5,60),(2518,'PM-60-30_1_14',2,60,999999,30,1.14,60),(2519,'PM-60-30_3_6',2,60,999999,30,3.6,60),(2520,'PM-60-30_5_44',2,60,999999,30,5.44,60),(2521,'PM-60-30_0_79',2,60,999999,30,0.79,60),(2522,'PM-60-30_3_42',2,60,999999,30,3.42,60),(2523,'PM-60-30_5_26',2,60,999999,30,5.26,60),(2524,'PM-60-30_0',2,60,999999,30,0,60),(2525,'PM_0_9',2,60,999999,30,0.9,60),(2526,'PM-60-30_1_27',2,60,999999,30,1.27,60),(2527,'PM-60-30_3_77',2,60,999999,30,3.77,60),(2528,'PM-60-30_5_53',2,60,999999,30,5.53,60),(2529,'PM-60-30_3_51',2,60,999999,30,3.51,60),(2530,'PMS_2_05',2,60,999999,30,2.05,60),(2531,'PMS_1_6',2,60,999999,30,1.6,60),(2532,'PMS_1_03',2,60,999999,30,1.03,60),(2533,'PMS_1_45',2,60,999999,30,1.45,60),(2534,'PMS_0_9',2,60,999999,30,0.9,60),(2535,'PMS_0_75',2,60,999999,30,0.75,60),(2536,'PM-60-30_0_66',2,60,999999,30,0.66,60),(2537,'PM_5_1',2,60,999999,30,5.1,60),(2538,'PM_4_9',2,60,999999,30,4.9,60),(2539,'PM_3_5',2,60,999999,30,3.5,60),(2540,'PM_3_4',2,60,999999,30,3.4,60),(2541,'PM_3_25',2,60,999999,30,3.25,60),(2542,'PM_5_9',2,60,999999,30,5.9,60),(2543,'PM_5_6',2,60,999999,30,5.6,60),(2544,'PM_4_7',2,60,999999,30,4.7,60),(2545,'PM_3_8',2,60,999999,30,3.8,60),(2546,'PM_4_65',2,60,999999,30,4.65,60),(2577,'PMD_1_14',1,0,999999999,1024,1.14,1024000),(2578,'PMD_1',1,0,999999999,1024,1,1024000);
/*!40000 ALTER TABLE `RATE_PRICE_PIVOT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RUM_MAP`
--

DROP TABLE IF EXISTS `RUM_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RUM_MAP` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `PRICE_GROUP` varchar(24) DEFAULT NULL,
  `PRICE_MODEL` varchar(24) DEFAULT NULL,
  `RUM` varchar(24) DEFAULT NULL,
  `RESOURCE` varchar(24) DEFAULT NULL,
  `RESOURCE_ID` int(11) DEFAULT NULL,
  `RUM_TYPE` varchar(24) DEFAULT NULL,
  `CONSUME_FLAG` int(11) DEFAULT NULL,
  `STEP` int(11) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1242 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RUM_MAP`
--

LOCK TABLES `RUM_MAP` WRITE;
/*!40000 ALTER TABLE `RUM_MAP` DISABLE KEYS */;
INSERT INTO `RUM_MAP` VALUES (1169,'PM_1_8','PM_1_8','DUR','MONEY',888,'TIERED',0,1),(1170,'PM_5','PM_5','DUR','MONEY',888,'TIERED',0,1),(1171,'PM_1_5','PM_1_5','DUR','MONEY',888,'TIERED',0,1),(1172,'PM_4_5','PM_4_5','DUR','MONEY',888,'TIERED',0,1),(1173,'PMS_0_04','PMS_0_04','DUR','MONEY',888,'TIERED',0,1),(1174,'PMS_6','PMS_6','DUR','MONEY',888,'TIERED',0,1),(1175,'PMS_5_7','PMS_5_7','DUR','MONEY',888,'TIERED',0,1),(1176,'PMS_5_8','PMS_5_8','DUR','MONEY',888,'TIERED',0,1),(1177,'PMS_5_5','PMS_5_5','DUR','MONEY',888,'TIERED',0,1),(1178,'PM-60-30_1_14','PM-60-30_1_14','DUR','MONEY',888,'TIERED',0,1),(1179,'PM-60-30_3_6','PM-60-30_3_6','DUR','MONEY',888,'TIERED',0,1),(1180,'PM-60-30_5_44','PM-60-30_5_44','DUR','MONEY',888,'TIERED',0,1),(1181,'PM-60-30_0_79','PM-60-30_0_79','DUR','MONEY',888,'TIERED',0,1),(1182,'PM-60-30_3_42','PM-60-30_3_42','DUR','MONEY',888,'TIERED',0,1),(1183,'PM-60-30_5_26','PM-60-30_5_26','DUR','MONEY',888,'TIERED',0,1),(1184,'PM-60-30_0','PM-60-30_0','DUR','MONEY',888,'TIERED',0,1),(1185,'PM_0_9','PM_0_9','DUR','MONEY',888,'TIERED',0,1),(1186,'PM-60-30_1_27','PM-60-30_1_27','DUR','MONEY',888,'TIERED',0,1),(1187,'PM-60-30_3_77','PM-60-30_3_77','DUR','MONEY',888,'TIERED',0,1),(1188,'PM-60-30_5_53','PM-60-30_5_53','DUR','MONEY',888,'TIERED',0,1),(1189,'PM-60-30_3_51','PM-60-30_3_51','DUR','MONEY',888,'TIERED',0,1),(1190,'PMS_2_05','PMS_2_05','DUR','MONEY',888,'TIERED',0,1),(1191,'PMS_1_6','PMS_1_6','DUR','MONEY',888,'TIERED',0,1),(1192,'PMS_1_03','PMS_1_03','DUR','MONEY',888,'TIERED',0,1),(1193,'PMS_1_45','PMS_1_45','DUR','MONEY',888,'TIERED',0,1),(1194,'PMS_0_9','PMS_0_9','DUR','MONEY',888,'TIERED',0,1),(1195,'PMS_0_75','PMS_0_75','DUR','MONEY',888,'TIERED',0,1),(1196,'PM-60-30_0_66','PM-60-30_0_66','DUR','MONEY',888,'TIERED',0,1),(1197,'PM_5_1','PM_5_1','DUR','MONEY',888,'TIERED',0,1),(1198,'PM_4_9','PM_4_9','DUR','MONEY',888,'TIERED',0,1),(1199,'PM_3_5','PM_3_5','DUR','MONEY',888,'TIERED',0,1),(1200,'PM_3_4','PM_3_4','DUR','MONEY',888,'TIERED',0,1),(1201,'PM_3_25','PM_3_25','DUR','MONEY',888,'TIERED',0,1),(1202,'PM_5_9','PM_5_9','DUR','MONEY',888,'TIERED',0,1),(1203,'PM_5_6','PM_5_6','DUR','MONEY',888,'TIERED',0,1),(1204,'PM_4_7','PM_4_7','DUR','MONEY',888,'TIERED',0,1),(1205,'PM_3_8','PM_3_8','DUR','MONEY',888,'TIERED',0,1),(1206,'PM_4_65','PM_4_65','DUR','MONEY',888,'TIERED',0,1),(1232,'PMD_1_14','PMD_1_14','VOL','MONEY',888,'TIERED',0,1),(1233,'PMD_1','PMD_1','VOL','MONEY',888,'TIERED',0,1),(1235,'PME_0_8','PME_0_8','EVT','MONEY',888,'EVENT',0,1),(1236,'PME_1_71','PME_1_71','EVT','MONEY',888,'EVENT',0,1),(1237,'PME_1_14','PME_1_14','EVT','MONEY',888,'EVENT',0,1),(1238,'PME_0_7','PME_0_7','EVT','MONEY',888,'EVENT',0,1),(1239,'PME_1_3','PME_1_3','EVT','MONEY',888,'EVENT',0,1),(1240,'PME_1','PME_1','EVT','MONEY',888,'EVENT',0,1);
/*!40000 ALTER TABLE `RUM_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SUSPENSE_MAP`
--

DROP TABLE IF EXISTS `SUSPENSE_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SUSPENSE_MAP` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `MAP_GROUP` varchar(24) NOT NULL,
  `ERROR_CODE` varchar(64) NOT NULL,
  `OUTPUT_NAME` varchar(24) NOT NULL,
  `RANK` int(11) NOT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SUSPENSE_MAP`
--

LOCK TABLES `SUSPENSE_MAP` WRITE;
/*!40000 ALTER TABLE `SUSPENSE_MAP` DISABLE KEYS */;
INSERT INTO `SUSPENSE_MAP` VALUES (1,'Default','.*','SuspenseOutput',99),(2,'Default','ERR_UNBILLED_RECORD','DiscardOutput',1);
/*!40000 ALTER TABLE `SUSPENSE_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TIME_MODEL_INTERVAL`
--

DROP TABLE IF EXISTS `TIME_MODEL_INTERVAL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TIME_MODEL_INTERVAL` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `TIME_MODEL_NAME_IN` varchar(24) DEFAULT NULL,
  `DAY_IN` varchar(24) DEFAULT NULL,
  `FROM_IN` varchar(24) DEFAULT NULL,
  `TO_IN` varchar(24) DEFAULT NULL,
  `RESULT_OUT` varchar(24) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TIME_MODEL_INTERVAL`
--

LOCK TABLES `TIME_MODEL_INTERVAL` WRITE;
/*!40000 ALTER TABLE `TIME_MODEL_INTERVAL` DISABLE KEYS */;
INSERT INTO `TIME_MODEL_INTERVAL` VALUES (25,'FLAT','0','00:00','23:59','FLAT'),(26,'FLAT','1','00:00','23:59','FLAT'),(27,'FLAT','2','00:00','23:59','FLAT'),(28,'FLAT','3','00:00','23:59','FLAT'),(29,'FLAT','4','00:00','23:59','FLAT'),(30,'FLAT','5','00:00','23:59','FLAT'),(31,'FLAT','6','00:00','23:59','FLAT'),(32,'Standard','1','00:00','06:59','VALUE'),(33,'Standard','1','07:00','19:59','PEAK'),(34,'Standard','1','20:00','21:59','OFFPEAK'),(35,'Standard','1','22:00','23:59','VALUE'),(36,'Standard','2','00:00','06:59','VALUE'),(37,'Standard','2','07:00','19:59','PEAK'),(38,'Standard','2','20:00','21:59','OFFPEAK'),(39,'Standard','2','22:00','23:59','VALUE'),(40,'Standard','3','00:00','06:59','VALUE'),(41,'Standard','3','07:00','19:59','PEAK'),(42,'Standard','3','20:00','21:59','OFFPEAK'),(43,'Standard','3','22:00','23:59','VALUE'),(44,'Standard','4','00:00','06:59','VALUE'),(45,'Standard','4','07:00','19:59','PEAK'),(46,'Standard','4','20:00','21:59','OFFPEAK'),(47,'Standard','4','22:00','23:59','VALUE'),(48,'Standard','5','00:00','06:59','VALUE'),(49,'Standard','5','07:00','19:59','PEAK'),(50,'Standard','5','20:00','21:59','OFFPEAK'),(51,'Standard','5','22:00','23:59','VALUE'),(52,'Standard','0','22:00','23:59','VALUE'),(53,'Standard','0','07:00','21:59','OFFPEAK'),(54,'Standard','0','00:00','06:59','VALUE'),(55,'Standard','6','22:00','23:59','VALUE'),(56,'Standard','6','07:00','21:59','OFFPEAK'),(57,'Standard','6','00:00','06:59','VALUE');
/*!40000 ALTER TABLE `TIME_MODEL_INTERVAL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TIME_MODEL_MAP`
--

DROP TABLE IF EXISTS `TIME_MODEL_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TIME_MODEL_MAP` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `PRODUCT_NAME_IN` varchar(64) DEFAULT NULL,
  `TIME_MODEL_OUT` varchar(24) DEFAULT NULL,
  UNIQUE KEY `ID` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TIME_MODEL_MAP`
--

LOCK TABLES `TIME_MODEL_MAP` WRITE;
/*!40000 ALTER TABLE `TIME_MODEL_MAP` DISABLE KEYS */;
INSERT INTO `TIME_MODEL_MAP` VALUES (1,'ANYTIME 750','Standard'),(3,'PS Zone(120)','Standard'),(4,'DISTRIBUTOR PACKAGE','Standard'),(5,'CONNECTA PLUS','Standard'),(6,'ANYTIME 500','Standard'),(7,'PMB','Standard'),(8,'Pay As You Go Dynamic PSB','Standard');
/*!40000 ALTER TABLE `TIME_MODEL_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'PixipDB'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_CreatePriceModels` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`openrate`@`localhost` PROCEDURE `sp_CreatePriceModels`(
)
BEGIN
delete from RATE_PRICE_PIVOT;


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,0,1,SETUP_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Event'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,999999,1,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat1'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,999999,1,RATE_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Beat1PS'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,0,1,SETUP_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Setup,Beat1'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,0,999999,1,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Setup,Beat1'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,0,1,SETUP_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Setup,Beat60'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,0,999999,60,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Setup,Beat60'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,1,1,1,SETUP_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Setup,Beat60,Beat1'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,0,60,60,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Setup,Beat60,Beat1'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,3,60,999999,1,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Setup,Beat60,Beat1'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,30,30,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat30,Beat1'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,30,999999,1,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat30,Beat1'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,60,60,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat60,Beat15'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,60,999999,15,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat60,Beat15'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,60,60,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat60,Beat30'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,60,999999,30,RATE_PRICE,60 from PRICE_MAP where RATING_TYPE = 'Beat60,Beat30'
);



insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,1,1,1,SETUP_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Setup,Markup'
);

insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,2,0,999999,0.01,RATE_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Setup,Markup'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,999999,0.01,RATE_PRICE,1 from PRICE_MAP where RATING_TYPE = 'Markup'
);


insert into RATE_PRICE_PIVOT (PRICE_MODEL,STEP,TIER_FROM,TIER_TO,BEAT,FACTOR,CHARGE_BASE)
(
  select distinct PRICE_GROUP,1,0,999999999,1024,RATE_PRICE,1024000 from PRICE_MAP where RATING_TYPE = 'MBBeat1kB'
);


delete from PRICE_MODEL;
insert into PRICE_MODEL
(
  select * from RATE_PRICE_PIVOT
);

DELETE FROM RUM_MAP;
INSERT INTO RUM_MAP (PRICE_GROUP,PRICE_MODEL,RUM,RESOURCE,RESOURCE_ID,RUM_TYPE,CONSUME_FLAG,STEP)
(
  select distinct PRICE_GROUP,PRICE_GROUP,'DUR','MONEY',888,'TIERED',0,1 from PRICE_MAP where RATING_TYPE in ('Setup,Beat60,Beat1','Setup,Beat1','Beat1','Beat1PS','Beat30,Beat1','Beat60,Beat15','Beat60,Beat30','Setup,Beat60')
);

INSERT INTO RUM_MAP (PRICE_GROUP,PRICE_MODEL,RUM,RESOURCE,RESOURCE_ID,RUM_TYPE,CONSUME_FLAG,STEP)
(
  select distinct PRICE_GROUP,PRICE_GROUP,'VOL','MONEY',888,'TIERED',0,1 from PRICE_MAP where RATING_TYPE in ('MBBeat1kB')
);

INSERT INTO RUM_MAP (PRICE_GROUP,PRICE_MODEL,RUM,RESOURCE,RESOURCE_ID,RUM_TYPE,CONSUME_FLAG,STEP)
(
  select distinct PRICE_GROUP,PRICE_GROUP,'EVT','MONEY',888,'EVENT',0,1 from PRICE_MAP where RATING_TYPE in ('Event')
);

INSERT INTO RUM_MAP (PRICE_GROUP,PRICE_MODEL,RUM,RESOURCE,RESOURCE_ID,RUM_TYPE,CONSUME_FLAG,STEP)
(
  select distinct PRICE_GROUP,PRICE_GROUP,'SEK','MONEY',888,'TIERED',0,1 from PRICE_MAP where RATING_TYPE in ('Markup','Setup,Markup')
);

select concat(count(*),' price models created') from RUM_MAP;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-20  8:02:52
